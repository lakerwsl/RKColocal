
public interface IntComparator {
	int compare(int a, int b);
}
