## ----setup, echo=FALSE-----------------------------------------------------
library(knitr)
.dpi = 100
set.seed(0)
opts_chunk$set(comment=NA, fig.align="center", dpi=.dpi)
knit_hooks$set(crop=NULL)
.output = output()
switch(.output,
        html = opts_chunk$set(fig.retina=1),
        latex = opts_chunk$set(out.width=".5\\textwidth")
)

.dev = switch(.output, html="svg", latex="pdf")

## ----installation, eval=FALSE----------------------------------------------
#  source("http://bioconductor.org/biocLite.R")
#  biocLite("RKColocal")

## ----library, message=FALSE, warning=FALSE, results='hide',error=FALSE-----
library("RKColocal")

## ----read image------------------------------------------------------------
f = system.file("images", "sample.jpeg", package = "RKColocal")
img = readImage(f)
X = imageData(img)[,,1]
Y = imageData(img)[,,2]

## ----image dimension-------------------------------------------------------
dim(X)

## ----display split, fig.width=dim(img)[1L]/.dpi*2, fig.height=dim(img)[2L]/.dpi, dpi=.dpi/4, fig.align="center"----
DualImageVisual(X, Y, isSplit = TRUE)

## ----display, fig.width=dim(img)[1L]/.dpi, fig.height=dim(img)[2L]/.dpi, dpi=.dpi/4,fig.align="center"----
DualImageVisual(X, Y, isSplit = FALSE)

## ----display mask, fig.width=dim(img)[1L]/.dpi, fig.height=dim(img)[2L]/.dpi, dpi=.dpi/4,fig.align="center"----
data(ROI)
display(ROI)

## ----display mask in image, fig.width=dim(img)[1L]/.dpi, fig.height=dim(img)[2L]/.dpi, dpi=.dpi/4,fig.align="center"----
DualImageVisual(X, Y, isSplit = FALSE, mask = ROI)

## ----writeImage, eval=FALSE------------------------------------------------
#  DualImageSave(X, Y, name = "sample.png", isSplit = TRUE, mask = ROI)

## ----scatter plot, fig.width=dim(img)[1L]/.dpi/2, fig.height=dim(img)[2L]/.dpi/2, out.width='55%', dpi=.dpi,fig.align="center"----
colocalplot(X, Y, method = 'scatter')

## ----li plot, fig.width=dim(img)[1L]/.dpi*2/2, fig.height=dim(img)[2L]/.dpi/2, out.width='200%', dpi=.dpi,fig.align="center"----
colocalplot(X, Y, mask = ROI, method = 'li')

## ----pearson index---------------------------------------------------------
colocalroi(X, Y, method = 'pearson')

## ----pearson index ROI-----------------------------------------------------
colocalroi(X, Y, mask = ROI, method = 'pearson')

## ----manders index1--------------------------------------------------------
colocalroi(X, Y, method = 'mandersM1')

## ----manders index2--------------------------------------------------------
colocalroi(X, Y, method = 'mandersM2')

## ----spearman index--------------------------------------------------------
colocalroi(X, Y, method = 'spearman')

## ----kendall index---------------------------------------------------------
colocalroi(X, Y, mask = ROI, method = 'kendall')

## ----icq index-------------------------------------------------------------
colocalroi(X, Y, method = 'icq')

## ----trunkendalln index----------------------------------------------------
colocalroi(X, Y, method = 'trunkendall')

## ----trunkendalln index thresholds, eval=FALSE-----------------------------
#  colocalroi(X, Y, Thresholds=c(0.5,0.5), method = 'trunkendall')

## ----pearson test----------------------------------------------------------
Testresult <- colocalroitest(X, Y, mask = ROI, method = 'pearson')
Testresult

## ----pearson test plot, fig.width=dim(img)[1L]/.dpi/1.2, fig.height=dim(img)[2L]/.dpi/2.5/1.2, out.width='80%', dpi=.dpi----
plot(Testresult)

## ----pearson test times, eval=FALSE----------------------------------------
#  colocalroitest(X, Y, mask = ROI, times = 1000, method = 'pearson')

## ----pearson test parallel, eval=FALSE-------------------------------------
#  colocalroitest(X, Y, mask = ROI, is.parallel = TRUE, numcore = 2, method = 'pearson')

## ----manders test, eval=FALSE----------------------------------------------
#  colocalroitest(X, Y, bsize = 32, method = 'mandersM2')

## ----laca------------------------------------------------------------------
saca <- colocalpixel(X, Y)
str(saca)

## ----laca identify, fig.width=dim(img)[1L]/.dpi, fig.height=dim(img)[2L]/.dpi, dpi=.dpi/4----
plot(saca)

## ----laca heat map, fig.width=dim(img)[1L]/.dpi/1.5, fig.height=dim(img)[2L]/.dpi, dpi=.dpi/2.5, out.width='80%', fig.align="center"----
HeatMapZ(saca)

## ----laca fdr, eval=FALSE--------------------------------------------------
#  colocalpixel(X, Y, method = 'BH')

